
$(function() {
    if (IEVersion() < 10) {
        return;
    }

    $(".videoContainer .mask").remove();
    $("footer").css({
        position: 'relative',
        'z-index': 20
    })
    $("#main").css({
        'margin-bottom': 0
    })
})

$(function() {
    if (IEVersion() >= 10) {
        return;
    }

    var $footer = $("#footer");
    var $main = $("#main");

    function setFooterGutter() {
        $main.css("margin-bottom", $footer.height());
    }

    setFooterGutter();
    $(window).on("resize", _.throttle(setFooterGutter, 200));
})